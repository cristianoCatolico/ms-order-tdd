package pe.ecclesia.cato;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsOrderTddApplicationTests {

	@Test
	void contextLoads() {
	}

}
