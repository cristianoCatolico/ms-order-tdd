package pe.ecclesia.cato;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsOrderTddApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsOrderTddApplication.class, args);
	}

}
